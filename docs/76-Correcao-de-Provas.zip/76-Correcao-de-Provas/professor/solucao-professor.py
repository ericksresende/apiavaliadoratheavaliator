def calcular_nota(gabarito, resposta):
    nota = 0
    for j in range(len(gabarito)):
        if resposta[j] == gabarito[j]:
            nota += 1  
    return nota

gabarito = input()
notas = dict()
entrada = input()
aprovados = 0
total = 0
dic_cont = {}

while entrada != '9999':
    numero,resposta = entrada.split()
    notas[numero] = resposta
    entrada = input()
    nota = calcular_nota(gabarito,resposta)
    print(numero, '%.1f' % nota)
    # Atualizando totais de aprovados e alunos
    total = total + 1
    if nota >= 6:
        aprovados += 1
    # Atualizando o dicion�rio das frequencias das notas
    dic_cont[nota] = dic_cont.get(nota, 0) + 1

# Impressao do percentual de aprovados
porcentagem = (aprovados * 100) / total
print(f'{porcentagem:.1f}%')

# Calculo da nota mais frequente
nota_mais_freq = None
num_ocorrencias = 0
for nota, freq in dic_cont.items():
    if freq > num_ocorrencias:
        nota_mais_freq = nota
        num_ocorrencias = freq
print('%.1f' % nota_mais_freq)