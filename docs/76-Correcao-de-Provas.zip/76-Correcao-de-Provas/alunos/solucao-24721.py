gabarito = input()
lista_gabarito = []
for g in gabarito:
  lista_gabarito.append(g)
lista_resp = []

dic = dict()
while True:
  prova = input()
  if prova == '9999':
    break
  else:
    prova = prova.split()
    n_aluno = int(prova[0])
    resp  = str(prova[1])

    dic[n_aluno] = resp

cont1 = 1
cont2 = 0
cont3 = 0
cont4 = 0

for i in sorted(dic):
  cont1 = 1
  cont2 = 0
  for j in dic[i][::-1]:
    if j == lista_gabarito[len(lista_gabarito) - cont1]:
      cont2 = cont2 + 1
    cont1 = cont1 + 1
  cont4 = cont4 + 1
  lista_resp.append(cont2)
  print(i, float(cont2))

for i in lista_resp:
  if i >= 6:
    cont3 = cont3 + 1
  media  = cont3/cont4*100
    
print('{:.1f}'.format(media)+'%')

max_atual = 0
iasmin = 0

for i in lista_resp:
  if lista_resp.count(i) >= iasmin:
    iasmin = lista_resp.count(i)
    max_atual = i
print(float(max_atual))
  



