def main():
    gab = str(input())

    contador = 0
    totaluno = 0
    acimamedia = 0
    d = dict()
    lista = []
    while True:
        aluno = input()
        m = aluno.split()
        if aluno == '9999':
            break

        y = m[len(m) - 1]
        for i in range(len(y)):
            if y[i] == gab[i]:
                contador = contador + 1
        print(m[0], '{:.1f}'.format(contador))

        if contador >= 6:
            acimamedia = acimamedia + 1

        lista.append(contador)

        contador = 0
        totaluno = totaluno + 1

    for i in lista:
        if i not in d:
            d[i] = 1
        else:
            d[i] = d[i] + 1

    maior = 0
    for i in d.values():
        if int(i) > maior:
            maior = int(i)

    percentual = (acimamedia / totaluno) * 100
    b = '{:.1f}'.format(percentual)
    print('{}%'.format(b))

    for i in d:
        if d[i] == maior:
            print('{:.1f}'.format(i))
