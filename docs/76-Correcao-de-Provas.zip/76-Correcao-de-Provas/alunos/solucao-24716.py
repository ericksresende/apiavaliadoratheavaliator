def Correcao(gabarito, entrada):
  aluno, prova = entrada.split()
  x,nota = 0,0
  for resposta in prova:
    if resposta == gabarito[x]:
      nota+=1
    x+=1
  return nota

notas = {}
aprovado, total_alunos = 0,0
gabarito = input()
entrada = input()
while entrada != '9999':
  total_alunos+=1
  nota = Correcao(gabarito, entrada)
  aluno, prova = entrada.split()
  print(aluno, '%.1f' % nota)
  if nota in notas:
    notas[nota]+=1
  if not(nota in notas):
    notas[nota] = 1 
  if nota>=6:
    aprovado+=1  
  entrada = input()


print('%.1f' % (aprovado/total_alunos * 100) + '%')

maxi = max(notas.values())
for n in notas.items():
  if n[1] == maxi:
    print('%.1f'%n[0])
    break