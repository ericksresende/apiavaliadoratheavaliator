def correcao(gabarito, entrada):
    aluno, prova = entrada.split()
    x = 0
    nota = 0
    for resposta in prova:
        if resposta == gabarito[x]:
            nota += 1
        x += 1
    return nota


notas = {}
aprovado = 0
totalalunos = 0
gabarito = input()
entrada = input()
while entrada != "9999":
    totalalunos += 1
    nota = correcao(gabarito, entrada)
    aluno, resposta = entrada.split()
    print(aluno, "{:.1f}".format(nota))
    if nota in notas:
        notas[nota] += 1
    if not (nota in notas):
        notas[nota] = 1
    if nota >= 6:
        aprovado += 1
    entrada = input()

print("{:.1f}".format(aprovado / totalalunos * 100) + "%")

maxi = max(notas.values())
for n in notas.items():
    if n[1] == maxi:
        print("{:.1f}".format(n[0]))
        break
