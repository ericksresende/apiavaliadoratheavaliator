gabarito = input()
x = input().split()
aluno_resposta = dict()
cont = 0
while "9999" not in x:
    aluno_resposta[int(x[0])] = x[1]
    x = input().split()
    cont += 1
aluno_nota = aluno_resposta.copy()
nota_frequencia = dict()
for b in range(0, 11):
    nota_frequencia[float(b)] = 0
    ac_media = 0
for i in range(1, cont + 1):
    cont2 = 0
    soma = 0
    a = aluno_nota[i]
    for j in gabarito:
        if a[cont2] == j:
            soma += 1
        cont2 += 1
    aluno_nota[i] = "%.1f" % soma
    if float(aluno_nota[i]) >= 6:
        ac_media += 1
    nota_frequencia[float(aluno_nota[i])] += 1
    print(i, aluno_nota[i])
porc = 100 * ac_media / len(aluno_nota)
print(str("%.1f" % porc) + "%")
parametro = None
for c in nota_frequencia:
    if parametro is None:
        maior = float(c)
        parametro = nota_frequencia[c]
    else:
        if nota_frequencia[c] > parametro:
            maior = float(c)
            parametro = nota_frequencia[c]
print(maior)
