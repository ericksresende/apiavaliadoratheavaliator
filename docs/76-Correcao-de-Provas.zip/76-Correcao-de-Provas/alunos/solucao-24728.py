gabarito=input()
respostas={}
line=input()
aprovados=0
while line!='9999':
 grade=0
 n,resposta=line.split() 
 n=int(n)
 for x in range(len(resposta)):
  if gabarito[x]==resposta[x]:
   grade+=1
 respostas[n]=grade
 line=input()
 if grade>=6:
  aprovados+=1
 print(n,'%.1f'%grade)
grades=list(respostas.values())
f=0
v=None
for grade in grades:
 s=grades.count(grade)
 if s>f:
  f=s
  v=grade
aprovacao=100*aprovados/len(respostas)  
print('{}%'.format('%.1f'%aprovacao))
print('%.1f'%v)
#abc
#1 aaa
#2 bbb
#3 ccc
#4 abc
#9999