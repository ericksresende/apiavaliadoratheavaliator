apr = 0
x = 0
d = {}
g = input()
while True:
  soma1 = 0
  a = input().split()
  if int(a[0]) == 9999:
    break
  n = int(a[0])
  r = a[1]
  for i in range(10):
    if g[i] == r[i]:
      soma1 += 1.0
  print(n,"%.1f"%soma1)
  if soma1 >= 6.0:
    apr += 1 
  d[soma1] = d.get(soma1,0) + 1 
  x += 1
apro = (apr/x)*100
print(str("%.1f"%apro)+"%")
b = max(d.values())
for c,v in d.items():
  if v == b:
    print("%.1f"%c)
    break


  