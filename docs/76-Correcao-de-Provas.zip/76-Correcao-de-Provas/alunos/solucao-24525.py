def calcular_nota(resp, gabarito):
  nota = 0
  for i in range(len(resp)):
    if resp[i] == gabarito[i]:
      nota = nota + 1
  return nota
relacao = dict()
gabarito = input()
resposta = input()
while resposta != "9999":
  numero, resp = resposta.split()
  relacao[int(numero)] = resp
  resposta = input()
respostas = relacao.values()
notas = []
for num in sorted(relacao):  
  nota = calcular_nota(relacao[num], gabarito)
  notas.append(nota)
  print("{} {:.1f}".format(num, nota))
media = 0
for x in notas:
  if x >= 6:
    media += 1
print("{:.1f}%".format((media/len(notas))*100)) 
contador = 0
moda = 0
for y in notas:
 qnt = notas.count(y)
 if qnt > contador:
   contador = qnt
   moda = y
print("{:.1f}".format(moda))