entrada = input()
notas = []
aprovacao = 0

while True:
  cont = 0
  aluno = input()
  if aluno == '9999':
    break
  num_aluno = aluno.split()[0]
  resposta = aluno.split()[1]
  for i in range(len(entrada)):
    if entrada[i] == resposta[i]:
      cont += 1
  print(num_aluno, '%.1f'%cont)
  if cont >= 6:
    aprovacao += 1
  notas.append(cont)

porcentagem = (aprovacao / len(notas)) * 100
print('%.1f%%'%porcentagem)

frequencia = {}
for i in notas:
  if i in frequencia:
    frequencia[i] += 1
  else:
    frequencia[i] = 1

maxi = max(frequencia.values())
for i in frequencia:
  if frequencia[i] == maxi:
    print('%.1f'%i)
    break