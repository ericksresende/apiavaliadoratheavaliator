gaba = input()
lista2 = []
iasmin_list = []
while True:
    cont = 0
    lista = []
    prova = input().split()
    if prova[0] == "9999":
        break
    for i in str(prova[1]):
        lista.append(i)
    for i in gaba:
        lista2.append(i)
    for i in range(len(lista)):
        if lista[i] == lista2[i]:
            cont += 1
    iasmin_list.append(float(cont))
    print(prova[0], "%.1f" % cont)
cont = 0
for i in ((iasmin_list)):
    if i >= 6:
        cont += 1
tax = "%.1f" % (cont * 100 / len(iasmin_list))
print(str(tax) + "%")

from collections import Counter

freq = Counter(iasmin_list).most_common(1)
freq = freq[0]
print(freq[0])
